function flag=test(lenchrom,bound,code)
% lenchrom   input : 
% bound      input : 
% code       output: 
x=code; %
flag=1;
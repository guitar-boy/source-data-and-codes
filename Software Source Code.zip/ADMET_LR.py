# -*- coding:utf-8 -*-
"""
@author:Lisa
@file:logisticRegression.py
@note:logistic
@time:
"""

import numpy as np
import matplotlib.pyplot as plt

"""

"""
def loadDataSet():
    dataMat=[]  #
    labelMat=[]
    txt=open(r'data\Caco2_train.txt')

    for line in txt.readlines():
        curLine = line.strip().split('\t')
        lineArr = []
        for i in range(474):
            lineArr.append(float(curLine[i]))
        dataMat.append(lineArr)
        labelMat.append(float(curLine[474]))
    ''''    
    for line in txt.readlines():
        lineArr=line.strip().split()        #strip():
                                            #split():
        dataMat.append( [1.0, float(lineArr[0]), float(lineArr[1]) ])  #
        labelMat.append(int(lineArr[2]) )
    '''
    return dataMat,labelMat


"""

"""
def sigmoid(z):
    return 1.0/(1+np.exp(-z) )

"""

"""
def gradAscent(dataMat,labelMat):
    dataSet=np.mat(dataMat)                          # m*n
    labelSet=np.mat(labelMat).transpose()            # 1*m->m*1
    m,n=np.shape(dataSet)                            # m*n:
    alpha=0.001                                      # 
    maxCycles=500                                    # 
    weights=np.ones( (n,1) )
    for i in range(maxCycles):
        y=sigmoid(dataSet * weights)                 # 
        error=labelSet -y
        weights=weights+ alpha *dataSet.transpose()*error
    #print(type(weights))
    return weights.getA(),weights  ##getA():,

"""

"""
def stocGradAscent0(dataMat,labelMat):
    m, n = np.shape(dataMat)  # m*n: 
    alpha = 0.001  # 
    maxCycles=500
    weights = np.ones(n)
    for cycle in range(maxCycles):
        for i in range(m):
            y = sigmoid(sum(dataMat[i] * weights) )  # 
            error = labelMat[i] - y
            weights = weights + alpha  * error* dataMat[i]
        # print(type(weights))
    return weights


"""

"""
def stocGradAscent1(dataMat,labelMat):

    m, n = np.shape(dataMat)  # m*n: 
    maxCycles = 150
    weights = np.ones(n)
    for cycle in range(maxCycles):
        dataIndex=list( range(m))
        for i in range(m):
            alpha = 4 / (1.0 + cycle + i) + 0.01                 # 
            randIndex=int(np.random.uniform(0,len(dataIndex) ))  #
            y = sigmoid(sum(dataMat[randIndex] * weights ))          # 
            error = labelMat[randIndex] - y
            weights = weights + alpha  * error * dataMat[randIndex]
            del(dataIndex[randIndex])
            # print(type(weights))
    return weights


"""

"""
def plotBestFit(weights):
    dataMat, labelMat = loadDataSet()
    dataArr=np.array(dataMat)
    m,n=np.shape(dataArr)
    x1=[]           #x1,y1:
    x2=[]           #x2,y2:
    y1=[]
    y2=[]
    for i in range(m):
        if (labelMat[i])==1:
            x1.append(dataArr[i,1])
            y1.append(dataArr[i,2])
        else:
            x2.append(dataArr[i,1])
            y2.append(dataArr[i,2])
    fig=plt.figure()
    ax=fig.add_subplot(1,1,1)
    ax.scatter(x1,y1,s=30,c='red',marker='s')
    ax.scatter(x2,y2,s=30,c='green')

    #
    x=np.arange(-3.0, 3.0, 0.1)
    y=(-weights[0]-weights[1]*x)/weights[2]    #
    ax.plot(x,y)

    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.show()




def main():
    dataMat,labelMat=loadDataSet()
    #weights=gradAscent(dataMat,labelMat)[0]
    weights = stocGradAscent0(np.array(dataMat), labelMat)
    #weights = stocGradAscent1(np.array(dataMat), labelMat)
    plotBestFit(weights)



if __name__ == '__main__':
    main()


output = [test_simu; output_test]';
xlswrite('Qian20_YiChuan_bpShenJing.xlsx', output);
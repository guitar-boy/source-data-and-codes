
clc;
clear;
num = xlsread('CACO2.xlsx', 'page_1');
select = randperm(1974);
[h, l] = size(num);
x_train = num(select(198: 1974),1:l - 1)';
y_train = num(select(198: 1974), l)';
x_test = num(select(1:197),1:l - 1)';
y_test = num(select(1:197),l)';

%
[x_train_regular,x_train_maxmin] = mapminmax(x_train);
[y_train_regular,y_train_maxmin] = mapminmax(y_train);
%
net=newff(x_train_regular,y_train_regular,6,{'tansig','tansig','purelin'},'trainlm');
% 
net.trainParam.epochs = 5000;
% 
net.trainParam.goal=0.0000001;
%
[net,tr]=train(net,x_train_regular,y_train_regular);

%

%
x_test_regular = mapminmax('apply',x_test,x_train_maxmin);
%
y_test_regular=sim(net,x_test_regular);
%
y_test_regular=mapminmax('reverse',y_test_regular,y_train_maxmin);
y_test_round = round(y_test_regular);
output = [y_test_round; y_test]';
xlswrite('CACO2_bpShenJing.xlsx', output);

x_test = xlsread('CACO2test.xlsx', 'page_1');
x_test_regular = mapminmax('apply',x_test', x_train_maxmin);
%
y_test_regular=sim(net,x_test_regular);
%
y_test_regular=mapminmax('reverse',y_test_regular,y_train_maxmin);
y_test_regular = round(y_test_regular);
xlswrite('CACO2_test_bp_pIC.xlsx', y_test_regular');




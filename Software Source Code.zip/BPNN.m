
clc;
clear;
num = xlsread('Qian20_pIC.xlsx', 'sheet1');
[h, l] = size(num);
x_train = num(:,1:l - 1)';
y_train = num(:, l)';

[x_train_regular,x_train_maxmin] = mapminmax(x_train);
[y_train_regular,y_train_maxmin] = mapminmax(y_train);
%
net=newff(x_train_regular,y_train_regular,6,{'tansig','tansig','purelin'},'trainlm');
% 
net.trainParam.epochs = 5000;
% 
net.trainParam.goal=0.0000001;
%
[net,tr]=train(net,x_train_regular,y_train_regular);


%
% select = randperm(h);
% select = select(1:50)
x_test = x_train;
%
x_test_regular = mapminmax('apply',x_test,x_train_maxmin);
%
y_test_regular=sim(net,x_test_regular);
%
y_test_regular=mapminmax('reverse',y_test_regular,y_train_maxmin);
y_test_regular;
output = [y_test_regular; y_train]';
xlswrite('Qian20_bpShenJing.xlsx', output);



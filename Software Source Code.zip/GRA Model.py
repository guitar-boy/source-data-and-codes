import pandas as pd
import os

#
x=pd.read_excel("E:\\DESKTOP\\08.xlsx", encoding='utf8')
columns1 = x.columns.values.tolist()
#print(x.columns.values[124])
x = (x - x.min())/(x.max() - x.min())
x=x.T

  
# 
ck=x.iloc[0,:]
cp=x.iloc[1:,:]

# 
t=pd.DataFrame()

for j in range(cp.index.size):
    temp=pd.Series(cp.iloc[j,:]-ck)
    t=t.append(temp,ignore_index=True)

#
mmax=t.abs().max().max()
mmin=t.abs().min().min()
rho=0.5
#
ksi=((mmin+rho*mmax)/(abs(t)+rho*mmax))

#
r=ksi.sum(axis=1)/ksi.columns.size


#print(type(r))
result1=pd.DataFrame(r)
#print(result1)

writer = pd.ExcelWriter('A.xlsx')		# 
result1.to_excel(writer, 'page_1', float_format='%.5f')
writer.save()

#%%

import numpy as np

paixuresult1 = np.sort(result1)
print(paixuresult1)
print(paixuresult1[0:100])




#%%


#5
result=r.sort_values(ascending=False)
#print(type(result))

dict_result ={'classlabel':result.index,'importance':result.values}
df_result = pd.DataFrame(dict_result)


#%%    
#print(df_result)
lastlabel = []
for i in df_result.iloc[0:101,0]:
   lastlabel.append(i) 

print(lastlabel)
#%%

labellist2=[]
for m in lastlabel:
    labellist2.append(columns1[m])
print(labellist2)  
    


#%%  
data=pd.read_excel("E:\\DESKTOP\\08.xlsx", encoding='utf8')
afterdata = data.loc[:,labellist2]   #
print(type(afterdata))


writer2 = pd.ExcelWriter('qu0MDqu.xlsx')		# 
afterdata.to_excel(writer2, 'page_1')		# ‘
writer2.save()





import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import xlrd

plt.rcParams.update({'font.size': 10.5})
plt.rcParams.update({'font.family' : 'Times New Roman'})

# load data
# 
workbook = xlrd.open_workbook(r'Molecular_Descriptor.xlsx')
# 
print(workbook.sheet_names())
# 
table = workbook.sheets()[0]
print(table.name)
# 
row = table.nrows # 
col = table.ncols # 
print(row)
print(col)


datamatrix = np.zeros((row, 1))
for i in range(col):
    cols = np.matrix(table.col_values(i)) # 
    # print(cols)
    datamatrix[:, 0] = cols # 

    #print(datamatrix)
    data = pd.DataFrame(datamatrix)

    fig = plt.figure(figsize = (10,6))
    ax1 = fig.add_subplot(2,1,1)  # 
    ax1.scatter(data.index, data.values)
    plt.grid()
    # 

    ax2 = fig.add_subplot(2,1,2)  # 
    data.hist(bins=30,alpha = 0.5,ax = ax2)
    data.plot(kind = 'kde', secondary_y=True,ax = ax2)
    plt.grid()
    plt.show()
  



'''
s = pd.DataFrame(np.random.randn(1000)+10,columns = ['value'])
print(s.head())
# 

fig = plt.figure(figsize = (10,6))
ax1 = fig.add_subplot(2,1,1)  #
ax1.scatter(s.index, s.values)
plt.grid()
# 

ax2 = fig.add_subplot(2,1,2)  # 
s.hist(bins=30,alpha = 0.5,ax = ax2)
s.plot(kind = 'kde', secondary_y=True,ax = ax2)
plt.grid()
# 
# 
'''

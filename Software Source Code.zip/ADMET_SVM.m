clear;
clc;

%%
num = xlsread('CACO2.xlsx', 'page_1');
[h, l] = size(num);
select = randperm(1974);
x_train = num(select(198: 1974),1:l - 1);
y_train = num(select(198: 1974), l);
x_test = num(select(1:197),1:l - 1);
y_test = num(select(1:197),l);
 
% 
[mtrain,ntrain] = size(x_train);
[mtest,ntest] = size(x_test);

test_dataset = [x_train;x_test];
% 
[dataset_scale, ps] = mapminmax(test_dataset',0,1);
dataset_scale = dataset_scale';
 
x_train = dataset_scale(1:mtrain,:);
x_test = dataset_scale((mtrain+1):(mtrain+mtest),: );
%% 

model = svmtrain(y_train, x_train, '-s 0 -t 2 -c 1.2 -g 2.8');

 
%% 
[predict_label] = svmpredict(y_test, x_test, model);

output = [predict_label, y_test];
xlswrite('CACO2_pIC.xlsx', output);

%% 
 
% 
% 
figure;
hold on;
plot(y_test,'o');
plot(predict_label,'r*');
grid on;
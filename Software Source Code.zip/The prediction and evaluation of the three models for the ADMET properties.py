import numpy as np
import xlrd
import xlsxwriter
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score

writer = pd.ExcelWriter('pingjia.xlsx') # 
data = np.zeros((5, 4))

# 
workbook = xlrd.open_workbook(r'CACO2_pIC.xlsx')
# 
table = workbook.sheets()[0]
y_pred = np.array(table.col_values(0))
y_true = np.array(table.col_values(1))
data[0, 0] = accuracy_score(y_true, y_pred)
data[0, 1] = precision_score(y_true, y_pred)
data[0, 2] = recall_score(y_true, y_pred)
data[0, 3] = f1_score(y_true, y_pred)


# 
workbook = xlrd.open_workbook(r'CYP3A4_pIC.xlsx')
# 
table = workbook.sheets()[0]
y_pred = np.array(table.col_values(0))
y_true = np.array(table.col_values(1))
data[1, 0] = accuracy_score(y_true, y_pred)
data[1, 1] = precision_score(y_true, y_pred)
data[1, 2] = recall_score(y_true, y_pred)
data[1, 3] = f1_score(y_true, y_pred)

# 
workbook = xlrd.open_workbook(r'hERG_pIC.xlsx')
# 
table = workbook.sheets()[0]
y_pred = np.array(table.col_values(0))
y_true = np.array(table.col_values(1))
data[2, 0] = accuracy_score(y_true, y_pred)
data[2, 1] = precision_score(y_true, y_pred)
data[2, 2] = recall_score(y_true, y_pred)
data[2, 3] = f1_score(y_true, y_pred)

# 
workbook = xlrd.open_workbook(r'MN_pIC.xlsx')
# 
table = workbook.sheets()[0]
y_pred = np.array(table.col_values(0))
y_true = np.array(table.col_values(1))
data[3, 0] = accuracy_score(y_true, y_pred)
data[3, 1] = precision_score(y_true, y_pred)
data[3, 2] = recall_score(y_true, y_pred)
data[3, 3] = f1_score(y_true, y_pred)

# 
workbook = xlrd.open_workbook(r'CACO2_pIC.xlsx')
# 
table = workbook.sheets()[0]
y_pred = np.array(table.col_values(0))
y_true = np.array(table.col_values(1))
data[4, 0] = accuracy_score(y_true, y_pred)
data[4, 1] = precision_score(y_true, y_pred)
data[4, 2] = recall_score(y_true, y_pred)
data[4, 3] = f1_score(y_true, y_pred)

print(data)

data = pd.DataFrame(data)
data.to_excel(writer, 'page_1', float_format='%.12f') 
writer.save()
